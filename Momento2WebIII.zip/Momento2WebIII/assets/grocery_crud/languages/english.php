<?php
	$lang['list_add'] 				= 'Agregar';
	$lang['list_actions'] 			= 'Acciones';
	$lang['list_page'] 				= 'Pagina';
	$lang['list_paging_of'] 		= 'de';
	$lang['list_displaying']		= 'Mostrando {start} a {end} de {results} items';
	$lang['list_filtered_from']		= '(filtered from {total_results} total entries)';
	$lang['list_show_entries']		= 'Mostrar {paging} entradas';
	$lang['list_no_items']			= 'No hay items para mostrar';
	$lang['list_zero_entries']		= 'Mostrando 0 a 0 de 0 items';
	$lang['list_search'] 			= 'Buscar';
	$lang['list_search_all'] 		= 'Buscar todos';
	$lang['list_clear_filtering'] 	= 'Limpiar filtro';
	$lang['list_delete'] 			= 'Eliminar';
	$lang['list_edit'] 				= 'Editar';
	$lang['list_paging_first'] 		= 'First';
	$lang['list_paging_previous'] 	= 'Previous';
	$lang['list_paging_next'] 		= 'Next';
	$lang['list_paging_last'] 		= 'Last';
	$lang['list_loading'] 			= 'Cargando...';

	$lang['form_edit'] 				= 'Editar';
	$lang['form_back_to_list'] 		= 'Volver a la lista';
	$lang['form_update_changes'] 	= 'Actualizar Cambios';
	$lang['form_cancel'] 			= 'Cancelar';
	$lang['form_update_loading'] 	= 'Cargando, actualizando cambios...';
	$lang['update_success_message'] = 'Sus datos se han actualizado con éxito.';
	$lang['form_go_back_to_list'] 	= 'Volver a la lista';

	$lang['form_add'] 				= 'Agregar';
	$lang['insert_success_message'] = 'Sus datos han sido almacenados con éxito en la base de datos.';
	$lang['form_or']				= 'o';
	$lang['form_save'] 				= 'Guardar';
	$lang['form_insert_loading'] 	= 'Cargando, guardando datos...';

	$lang['form_upload_a_file'] 	= 'Cargar un archivo';
	$lang['form_upload_delete'] 	= 'Eliminar';
	$lang['form_button_clear'] 		= 'Limpiar';

	$lang['delete_success_message'] = 'Your data has been successfully deleted from the database.';
	$lang['delete_error_message'] 	= 'Your data was not deleted from the database.';

	/* Javascript messages */
	$lang['alert_add_form']			= 'Es posible que los datos que ha insertado no se guarden.\\nEstás seguro de que quieres volver a la lista?';
	$lang['alert_edit_form']		= 'Los datos que ha cambiado, pueden no ser guardados.\\nEstás seguro de que quieres volver a la lista?';
	$lang['alert_delete']			= 'Estás seguro de que quieres Eliminar este registro?';

	$lang['insert_error']			= 'An error has occurred on insert.';
	$lang['update_error']			= 'An error has occurred on saving.';

	/* Added in version 1.2.1 */
	$lang['set_relation_title']		= 'Seleccionar {field_display_as}';
	$lang['list_record']			= 'Vista previa de ';
	$lang['form_inactive']			= 'inactive';
	$lang['form_active']			= 'active';

	/* Added in version 1.2.2 */
	$lang['form_save_and_go_back']	= 'Guardar y volver a la lista';
	$lang['form_update_and_go_back']= 'Actualizar y volver a la lista';

	/* Upload functionality */
	$lang['string_delete_file'] 	= "Deleting file";
	$lang['string_progress'] 		= "Progress: ";
	$lang['error_on_uploading'] 	= "An error has occurred on uploading.";
	$lang['message_prompt_delete_file'] 	= "Are you sure that you want to delete this file?";

	$lang['error_max_number_of_files'] 	= "You can only upload one file each time.";
	$lang['error_accept_file_types'] 	= "You are not allow to upload this kind of extension.";
	$lang['error_max_file_size'] 		= "The uploaded file exceeds the {max_file_size} directive that was specified.";
	$lang['error_min_file_size'] 		= "You cannot upload an empty file.";

	/* Added in version 1.3.1 */
	$lang['list_export'] 	= "Exportar";
	$lang['list_print'] 	= "Imprimir";
	$lang['minimize_maximize'] = 'Minimize/Maximize';
	
	/* Added in version 1.4 */
	$lang['list_view'] = 'Ver';

	/* Added in version 1.5.1 */
	$lang['ui_day'] = 'dd';
	$lang['ui_month'] = 'mm';
	$lang['ui_year'] = 'yyyy';

	/* Added in version 1.5.2 */
	$lang['list_more'] = 'More';

	/* Added in version 1.5.6 */
	$lang['list_search_column'] = 'Buscar {column_name}';

	/* Added in version 1.5.8 */
	$lang['alert_delete_multiple'] = 'Are you sure that you want to delete those {items_amount} items?';
	$lang['alert_delete_multiple_one'] = 'Are you sure that you want to delete this 1 item?';

	/* Added in version 1.6.1 */
	$lang['list_clone'] = 'Clonar';

