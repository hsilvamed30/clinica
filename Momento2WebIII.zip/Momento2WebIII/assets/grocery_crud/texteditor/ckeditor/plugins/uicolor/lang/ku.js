﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'uicolor', 'ku',
{
	uicolor :
	{
		title : 'هه‌ڵگری ڕه‌نگ بۆ ڕووکاری به‌کارهێنه‌ر',
		preview : 'پێشبینین به‌ زیندوویی',
		config : 'ئه‌م ده‌قانه‌ بلکێنه‌ به‌ په‌ڕگه‌ی config.js-fil',
		predefined : 'کۆمه‌ڵه‌ ڕه‌نگه‌ دیاریکراوه‌کانی پێشوو'
	}
});
