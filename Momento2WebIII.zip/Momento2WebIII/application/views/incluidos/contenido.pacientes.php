<?php
/*
Este script contiene el cuerpo principal del CRUD De tipos de clientes
*/
?>
  <div class="content-wrapper">
    <section class="content-header">
      <div class="center">
         <h1>
          Clinica Web III   
        </h1>
        <div class="row menu-site">
          <a href="<?php echo site_url()?>/pacientes">Pacientes</a>
          <a href="<?php echo site_url()?>/sangre">Tipos de Sangre</a>
          <a href="<?php echo site_url()?>/enfermedades">Enfermedades</a>
        </div>
      </div>    

    </section>

    <div class="container">
      <section class="content">
        <h2 class="obser">
          Lista de Pacientes 
        </h2>
        <?php echo $tabla;?>

      </section>
    </div>

        <section class="content-header content-footer">
          <div class="container">
             <h4 class="obser">
              Nuestra Historia 
             </h4>
             <p>
              La Clinica Web III es hoy una de las más importantes instituciones de salud en Colombia.
              <br/>
              El trabajo permanente en pro de la salud de nuestros pacientes, el compromiso con la calidad, la seguridad en la atención y la amabilidad de nuestro personal, nos han permitido a los largo de los años, obtener múltiples reconocimientos de entidades locales y nacionales. 
          </div>    
        </section>
    
  </div>
